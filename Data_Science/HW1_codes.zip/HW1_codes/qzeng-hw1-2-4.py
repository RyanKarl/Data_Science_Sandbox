
import matplotlib.pyplot as plt
import numpy as np
import os


def ReadData():
    fr = open(os.path.abspath('.')+ "/datasets/Dataset-film-data.csv", "r")
    feature1 = []
    feature2 = []
    feature3 = []
    feature4 = []
    gen = {}
    id2gen_feature ={}
    count = 0
    for line in fr:
        if count!= 0:
            line =  line.rstrip("\n").split(",")
            feature1.append(float(line[1]))
            feature2.append(float(line[2]))
            feature3.append(float(line[3]))
            feature4.append(float(line[4]))
            if line[5] not in gen:
                gen[line[5]] = [1,float(line[1]),float(line[3])]
            else:
                gen[line[5]][0] += 1
                gen[line[5]][1] += float(line[1])
                gen[line[5]][2] += float(line[3])
            if line[0] not in id2gen_feature:
                id2gen_feature[line[0]] = [line[5],float(line[1]),float(line[2]),float(line[3]),float(line[4])]

            count += 1
        else:
            count += 1
            continue


    return feature1, feature2, feature3, feature4, gen,id2gen_feature

if __name__  == "__main__":
    feature1, feature2, feature3, feature4, gen ,id2gen_feature= ReadData()
    print(id2gen_feature)
    ACTION1 =[]
    ROMANCE1 = []
    COMEDY1 = []
    ACTION3 =[]
    ROMANCE3 = []
    COMEDY3 = []
    for id in id2gen_feature:
        if id2gen_feature[id][0] == 'ACTION':
            ACTION1.append(id2gen_feature[id][1])
            ACTION3.append(id2gen_feature[id][3])
        elif id2gen_feature[id][0] == 'ROMANCE':
            ROMANCE1.append(id2gen_feature[id][1])
            ROMANCE3.append(id2gen_feature[id][3])
        elif id2gen_feature[id][0] == 'COMEDY':
            COMEDY1.append(id2gen_feature[id][1])
            COMEDY3.append(id2gen_feature[id][3])


    fig = plt.figure()

    plt.scatter(ACTION1,ACTION3,s=30,c='red',marker='o',alpha=0.5,label='ACTION')
    plt.scatter(ROMANCE1,ROMANCE3,s=30,c='blue',marker='x',alpha=0.5,label='ROMANCE')
    plt.scatter(COMEDY1,COMEDY3,s=30,c='green',marker='*',alpha=0.5,label='COMEDY')
    plt.title("Scatter Plot")
    plt.xlabel('AVGRATING_WEBSITE_1')
    plt.ylabel('AVGRATING_WEBSITE_3')


    plt.show()