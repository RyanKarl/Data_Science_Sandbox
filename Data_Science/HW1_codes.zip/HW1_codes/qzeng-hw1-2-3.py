
import matplotlib.pyplot as plt
import numpy as np
import os
def ReadData():
    fr = open(os.path.abspath('.')+ "/datasets/Dataset-film-data.csv", "r")
    feature1 = []
    feature2 = []
    feature3 = []
    feature4 = []
    gen = {}
    count = 0
    for line in fr:
        if count!= 0:
            line =  line.rstrip("\n").split(",")
            feature1.append(float(line[1]))
            feature2.append(float(line[2]))
            feature3.append(float(line[3]))
            feature4.append(float(line[4]))
            if line[5] not in gen:
                gen[line[5]] = [1,float(line[1])]
            else:
                gen[line[5]][0] += 1
                gen[line[5]][1] += float(line[1])

            count += 1
        else:
            count += 1
            continue


    return feature1, feature2, feature3, feature4, gen
if __name__  == "__main__":
    feature1, feature2, feature3, feature4, gen = ReadData()
    print(gen)
    print("start plot")
    objects = ('ACTION', 'ROMANCE', 'COMEDY')
    y_pos = np.arange(len(objects))
    average = [gen['ACTION'][1]/gen['ACTION'][0],gen['ROMANCE'][1]/gen['ROMANCE'][0],gen['COMEDY'][1]/gen['COMEDY'][0] ]

    plt.bar(y_pos, average)
    plt.xticks(y_pos, objects)
    plt.ylabel('Average')

    plt.show()
