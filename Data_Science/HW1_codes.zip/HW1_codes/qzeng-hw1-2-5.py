
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os

dataset = os.path.abspath('.')+ "/datasets/Dataset-film-data.csv"
df = pd.read_csv(dataset)

data1 = df['AVGRATING_WEBSITE_1'].tolist()
data2 = df['AVGRATING_WEBSITE_3'].tolist()

data1.sort()
data2.sort()

x = data1
y = data2

plt.scatter(
    x=x,
    y=y,
)
plt.plot(x,y)
plt.plot([data1[0],data1[-1]],[data2[0],data2[-1]], '-.')
plt.xlabel('AVGRATING_WEBSITE_1')
plt.ylabel('AVGRATING_WEBSITE_3')
plt.title("Q-Q Plot")


plt.show()