
import pandas as pd
import numpy as np
from numpy import linalg as LA
from sklearn.preprocessing import normalize
from scipy.sparse.linalg import svds
from matplotlib.mlab import PCA
import matplotlib.pyplot as plt

from math import sqrt

# a large number t
T = 100

dataset = 'Dataset-film-data.csv'
df = pd.read_csv(dataset)
df = df.drop(columns=['FILM_ID','GENRE'])

A = normalize(np.array(df),axis = 1)
_U = normalize(np.array([1]*150).reshape(1,-1))

for T in range(1):
    _V = normalize(np.matmul(_U, A).reshape(1,-1))
    _U = normalize(np.matmul(_V, A.T).reshape(1,-1))

_U = _U.reshape(-1,1)
print(_V)

U,S, V = svds(A,k=1)
print(V)
