
import matplotlib.pyplot as plt
import os
def ReadData():
    fr = open(os.path.abspath('.')+ "/datasets/Dataset-film-data.csv", "r")
    feature1 = []
    feature2 = []
    feature3 = []
    feature4 = []
    count = 0
    for line in fr:
        if count!= 0:
            line =  line.rstrip("\n").split(",")
            feature1.append(float(line[1]))
            feature2.append(float(line[2]))
            feature3.append(float(line[3]))
            feature4.append(float(line[4]))

            count += 1
        else:
            count += 1
            continue

    return feature1, feature2, feature3, feature4

if __name__  == "__main__":
    feature1, feature2, feature3, feature4 = ReadData()
    print("start plot")
    plt.figure()
    plt.boxplot(feature1)
    plt.ylabel('Rating')
    plt.title("Website_1 Box Plot")
    plt.show()




