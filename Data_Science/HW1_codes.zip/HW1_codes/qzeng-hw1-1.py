from scipy import stats
import os
def ReadData():
    fr = open(os.path.abspath('.')+ "/datasets/Dataset-film-data.csv", "r")
    feature1 = []
    feature2 = []
    feature3 = []
    feature4 = []
    count = 0
    for line in fr:
        if count!= 0:
            line =  line.rstrip("\n").split(",")
            feature1.append(float(line[1]))
            feature2.append(float(line[2]))
            feature3.append(float(line[3]))
            feature4.append(float(line[4]))

            count += 1
        else:
            count += 1
            continue

    return feature1, feature2, feature3, feature4

if __name__  == "__main__":
    feature1, feature2, feature3, feature4  = ReadData()
    # z-score
    f1 = stats.zscore(feature1)
    f2 = stats.zscore(feature2)
    f3 = stats.zscore(feature3)
    f4 = stats.zscore(feature4)

    max_f_1 = max(f1)
    min_f_1 = min(f1)
    max_f_2 = max(f2)
    min_f_2 = min(f2)
    max_f_3 = max(f3)
    min_f_3 = min(f3)
    max_f_4 = max(f4)
    min_f_4 = min(f4)

    print(max_f_1, min_f_1)
    print(max_f_2, min_f_2)
    print(max_f_3, min_f_3)
    print(max_f_4, min_f_4)
