import numpy as np
import os
def ReadData():
    fr = open(os.path.abspath('.')+ "/datasets/Dataset-film-data.csv", "r")
    feature1 = []
    feature2 = []
    feature3 = []
    feature4 = []
    gen = {}
    id2gen_feature ={}
    count = 0
    for line in fr:
        if count!= 0:
            line =  line.rstrip("\n").split(",")
            feature1.append(float(line[1]))
            feature2.append(float(line[2]))
            feature3.append(float(line[3]))
            feature4.append(float(line[4]))
            if line[5] not in gen:
                gen[line[5]] = [1,float(line[1]),float(line[3])]
            else:
                gen[line[5]][0] += 1
                gen[line[5]][1] += float(line[1])
                gen[line[5]][2] += float(line[3])
            if line[0] not in id2gen_feature:
                id2gen_feature[line[0]] = [line[5],float(line[1]),float(line[2]),float(line[3]),float(line[4])]

            count += 1
        else:
            count += 1
            continue


    return feature1, feature2, feature3, feature4, gen,id2gen_feature
if __name__  == "__main__":
    feature1, feature2, feature3, feature4, gen,id2gen_feature = ReadData()

    corrcoef12 = np.corrcoef(feature1, feature2)
    print("p1,2", corrcoef12[0,1])

    corrcoef12 = np.corrcoef(feature1, feature3)
    print("p1,3", corrcoef12[0,1])

    corrcoef12 = np.corrcoef(feature2, feature3)
    print("p2,3", corrcoef12[0,1])
