import pandas as pd
import numpy as np
from scipy.sparse.linalg import svds
import matplotlib.pyplot as plt
import os

def ReadData():
    fr = open(os.path.abspath('.')+ "/datasets/Dataset-film-data.csv", "r")
    feature1 = []
    feature2 = []
    feature3 = []
    feature4 = []
    count = 0
    for line in fr:
        if count!= 0:
            line =  line.rstrip("\n").split(",")
            feature1.append(float(line[1]))
            feature2.append(float(line[2]))
            feature3.append(float(line[3]))
            feature4.append(float(line[4]))

            count += 1
        else:
            count += 1
            continue

    return feature1, feature2, feature3, feature4

if __name__  == "__main__":
    feature1, feature2, feature3, feature4 = ReadData()
    matrix_1 = np.array([feature1, feature2, feature3, feature4])
    matrix_1 = matrix_1.T
    U,S,V = svds(matrix_1,k=2)
    ndf = pd.DataFrame(U)
    ndf.columns = ['V1', 'V2']
    raw_df = pd.read_csv(os.path.abspath('.')+ "/datasets/Dataset-film-data.csv")
    ndf['GENRE'] = raw_df['GENRE']

    colors = {'ACTION':'red', 'ROMANCE':'blue', 'COMEDY':'green'}
    markers = {'ACTION':'*', 'ROMANCE':'^', 'COMEDY':'o'}


    groups = ndf.groupby('GENRE')
    for name, group in groups:
        plt.scatter(
            x=group['V1'],
            y=group['V2'],
            c=colors[name],
            marker=markers[name]
        )

    plt.legend(
        ['ACTION','ROMANCE','COMEDY'],
        loc='best', shadow=True, fancybox=True)

    plt.title("Plotting samples on first two principle components")
    plt.xlabel('V1')
    plt.ylabel('V2')
    plt.show()